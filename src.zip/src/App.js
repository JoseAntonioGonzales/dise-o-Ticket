import React from 'react';
import './index.css';
import Inicio from './PgnIniSucursal/inicio';
import Infra from './PgnInicioInfra/inicioInfra';


function App() {
  return (
    <div className="App">
      <Infra />
    </div>
  );
}

export default App;
