import React from 'react';
import './index.css';
import Inicio from './PgnIniSucursal/inicio';

function App() {
  return (
    <div className="App">
      <Inicio />
    </div>
  );
}

export default App;
